const axios = require('axios');
const fs = require('fs');

const UPDATE_CONFIG = {
    versionUrl: 'https://raw.githubusercontent.com/NinoNeoxus/schnuffelll-database/main/version.json',
    localVersionFile: './version.json'
};

function getLocalVersion() {
    try {
        if (fs.existsSync(UPDATE_CONFIG.localVersionFile)) {
            return JSON.parse(fs.readFileSync(UPDATE_CONFIG.localVersionFile, 'utf8'));
        }
    } catch (e) {
        console.error('Error reading local:', e.message);
    }
    return { version: '0.0', build: '0' };
}

async function getRemoteVersion() {
    try {
        console.log("Fetching remote version...");
        // Add random query param to bust cache
        const response = await axios.get(`${UPDATE_CONFIG.versionUrl}?t=${Date.now()}`);
        return response.data;
    } catch (e) {
        console.error('Error fetching remote:', e.message);
        return null;
    }
}

function isNewerVersion(local, remote) {
    console.log(`Comparing Local: '${local}' vs Remote: '${remote}'`);

    // Remove -beta, -alpha, etc. for comparison
    const cleanLocal = local.replace(/-.*/, '');
    const cleanRemote = remote.replace(/-.*/, '');

    console.log(`Cleaned: '${cleanLocal}' vs '${cleanRemote}'`);

    const localParts = cleanLocal.split('.').map(Number);
    const remoteParts = cleanRemote.split('.').map(Number);

    for (let i = 0; i < Math.max(localParts.length, remoteParts.length); i++) {
        const l = localParts[i] || 0;
        const r = remoteParts[i] || 0;
        if (r > l) {
            console.log(`Part ${i}: Remote ${r} > Local ${l} => NEWER`);
            return true;
        }
        if (r < l) {
            console.log(`Part ${i}: Remote ${r} < Local ${l} => OLDER`);
            return false;
        }
    }
    console.log("Versions match exactly.");
    return false;
}

async function runTest() {
    const local = getLocalVersion();
    const remote = await getRemoteVersion();

    if (!remote) {
        console.log("❌ Failed to get remote version.");
        return;
    }

    console.log(`\n📄 Local Version: ${local.version} (Build ${local.build})`);
    console.log(`☁️ Remote Version: ${remote.version} (Build ${remote.build})`);

    const updateAvailable = isNewerVersion(local.version, remote.version);

    // Also check build number fallback
    const buildUpdate = parseInt(remote.build) > parseInt(local.build);

    if (updateAvailable) {
        console.log("\n✅ UPDATE AVAILABLE (Version Mismatch)");
    } else if (buildUpdate) {
        console.log("\n✅ UPDATE AVAILABLE (Build Mismatch)");
    } else {
        console.log("\n❌ NO UPDATE DETECTED");
    }
}

runTest();
